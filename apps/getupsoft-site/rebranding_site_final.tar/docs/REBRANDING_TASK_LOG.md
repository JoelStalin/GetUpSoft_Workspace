# LOG MAESTRO DE TAREAS Y CONTEXTO: REBRANDING GETUPSOFT / ORCA 2026

## 1. Contexto de Prompts Recibidos

### Prompt A: Voicebot Automation (Fase 1)
- **Objetivo:** Implementar MVP de Voicebot con Asterisk 20 y Python ARI.
- **Identidad Inicial:** `ai-automation-orchestrator`.
- **Tarea Clave:** Renombrar el proyecto a `orca`.

### Prompt B: Rebranding Estratégico (Fase 2)
- **Objetivo:** Diferenciar Getupsoft Global (`.com`) de Getupsoft Local (`.com.do`).
- **Concepto:** Minimalismo Moderno, Pasteles Oscuros.
- **Audiencia:** Estratégica (Global) vs Operativa (RD).

### Prompt C: Instagram Integration (Fase 3)
- **Objetivo:** Aplicar rebranding a la cuenta `getupsoft_` usando API.
- **Restricción:** No afectar cuentas personales.

## 2. Registro de Tareas Ejecutadas

### Infraestructura y Core
- [x] Renombrado de directorio `ai-automation-orchestrator` a `orca`.
- [x] Creación de estructura `voicebot-asterisk` (Scripts, Config, Bot Python).
- [x] Integración de `mark-xxxix` como el "Cerebro" de Orca.
- [x] Rebranding masivo de `mark-xxxix`: Jarvis -> Orca / Getupsoft.
- [x] Sincronización visual de la UI de Orca (ui.py) con paleta Dark Pastel.

### Web (Getupsoft Site)
- [x] Diseño e implementación de 5 páginas para `getupsoft.com` (Global/Indigo).
- [x] Diseño e implementación de 5 páginas para `getupsoft.com.do` (Local/Mint).
- [x] Validación de interconexión y navegación dual con Selenium.
- [x] Generación de evidencias visuales (Capturas de pantalla).

### EasyCounting (Sub-brand)
- [x] Rebranding integral de 4 portales (Admin, Cliente, Socios, Corporativo).
- [x] Unificación de base de datos a Postgres 16 (pgvector).
- [x] Actualización de identidad visual a Mint Pastel.
- [x] Sincronización de archivos fuente en el servidor.

## 3. Próximas Tareas en Ejecución (Auto-pilot)
- [ ] Rebranding de la documentación del Voicebot (Sincronizar con Orca).
- [ ] Creación de Plantillas de Posts para Instagram (HTML/Tailwind).
- [ ] Barrido final de strings antiguos (Jarvis, ai-automation) en todo el workspace.

---
*Este documento se actualiza automáticamente para mantener la trazabilidad del proyecto.*
