import { Link } from "react-router-dom";

const proof = [
  { label: "Software", value: "Portales y productos operativos" },
  { label: "Infrastructure", value: "Deployments, observability, delivery" },
  { label: "Automation", value: "Flujos, integraciones y trabajo repetible" },
];

const capabilities = [
  {
    name: "Product Platforms",
    description:
      "Portales administrativos, superficies cliente y experiencias multi-tenant diseñadas para trabajo real, no para demos vacias.",
  },
  {
    name: "Business Workflows",
    description:
      "Procesos que cruzan ventas, operaciones, soporte y backoffice sin depender de hojas sueltas o tareas manuales frágiles.",
  },
  {
    name: "Cloud Delivery",
    description:
      "Infraestructura, despliegues, dominios, monitoreo y controles de entorno para que el sistema siga operando cuando el equipo crece.",
  },
  {
    name: "Integration Layer",
    description:
      "Conectores y middleware para Odoo, facturación, catálogos, documentos y eventos de negocio con contratos claros.",
  },
];

const workflow = [
  {
    step: "01",
    title: "Mapeamos la operación",
    description:
      "Identificamos dónde se rompen los handoffs entre personas, herramientas y sistemas antes de proponer pantallas.",
  },
  {
    step: "02",
    title: "Construimos el sistema",
    description:
      "Diseñamos producto, integraciones y automatización como una sola unidad, con ownership técnico claro.",
  },
  {
    step: "03",
    title: "Lo dejamos operable",
    description:
      "Entrega con entornos, observabilidad, rutas de despliegue y una base que puede mantenerse sin improvisación.",
  },
];

export function HomePage() {
  return (
    <div>
      <section className="border-b border-slate-200/80">
        <div className="mx-auto grid min-h-[calc(100vh-88px)] max-w-7xl gap-14 px-6 py-16 lg:grid-cols-[1.05fr,0.95fr] lg:items-center lg:py-20">
          <div className="space-y-8">
            <div className="space-y-5">
              <span className="inline-flex items-center rounded-full border border-slate-300 bg-white px-4 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-slate-600">
                GetUpSoft
              </span>
              <div className="space-y-4">
                <h1 className="max-w-4xl text-5xl font-semibold leading-[1.02] text-ink sm:text-6xl">
                  Software, infrastructure, and automation for companies that need operations to move cleanly.
                </h1>
                <p className="max-w-2xl text-lg leading-8 text-slate-600 sm:text-xl">
                  GetUpSoft diseña sistemas operativos digitales para equipos que necesitan vender, ejecutar, integrar y entregar
                  con menos fricción. Nuestro producto principal es <span className="font-semibold text-ink">EasyCount by GetUpSoft</span>,
                  y nuestra capacidad va más allá del producto: arquitectura, automatización y delivery.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <Link
                className="inline-flex items-center rounded-full bg-ink px-6 py-3 text-sm font-semibold text-white transition hover:bg-slate-800"
                to="/productos/easycount"
              >
                Ver EasyCount
              </Link>
              <Link
                className="inline-flex items-center rounded-full border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-800 transition hover:border-accent hover:text-accent"
                to="/plataforma"
              >
                Explorar la plataforma
              </Link>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              {proof.map((item) => (
                <div key={item.label} className="border-t border-slate-300 pt-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">{item.label}</p>
                  <p className="mt-2 text-sm leading-6 text-slate-700">{item.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(15,118,110,0.16),transparent_38%),radial-gradient(circle_at_bottom_right,rgba(194,65,12,0.12),transparent_30%)]" />
            <div className="relative overflow-hidden rounded-[32px] border border-slate-200 bg-slate-950 px-6 py-6 text-white shadow-[0_30px_80px_rgba(15,23,42,0.14)]">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <p className="text-xs uppercase tracking-[0.24em] text-white/55">Operating Surface</p>
                  <p className="mt-2 text-xl font-semibold">GetUpSoft delivery model</p>
                </div>
                <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70">Live</div>
              </div>

              <div className="grid gap-4 pt-5">
                <div className="grid gap-3 sm:grid-cols-[1.15fr,0.85fr]">
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                    <p className="text-xs uppercase tracking-[0.24em] text-white/45">Workstreams</p>
                    <div className="mt-4 space-y-3">
                      {[
                        ["Portal layer", "Admin, client, partner surfaces"],
                        ["Automation layer", "Triggered jobs, orchestration, retries"],
                        ["Integration layer", "Business events, APIs, middleware"],
                      ].map(([title, description]) => (
                        <div key={title} className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3">
                          <p className="text-sm font-semibold">{title}</p>
                          <p className="mt-1 text-sm leading-6 text-white/65">{description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid gap-3">
                    {[
                      ["Environments", "Dev / Stg / Prod"],
                      ["Observability", "Logs, traces, alerts"],
                      ["Handoffs", "Business-ready operations"],
                    ].map(([title, value]) => (
                      <div key={title} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                        <p className="text-xs uppercase tracking-[0.22em] text-white/45">{title}</p>
                        <p className="mt-4 text-base font-semibold">{value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="flex flex-wrap items-center gap-3 text-sm text-white/70">
                    <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-emerald-200">
                      Product build
                    </span>
                    <span className="rounded-full border border-sky-400/30 bg-sky-400/10 px-3 py-1 text-sky-200">Infra ready</span>
                    <span className="rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-amber-100">
                      Automation in place
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="max-w-3xl space-y-4">
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-accent">What we build</p>
          <h2 className="text-3xl font-semibold text-ink sm:text-4xl">No vendemos solo un portal. Diseñamos el sistema que lo sostiene.</h2>
          <p className="text-lg leading-8 text-slate-600">
            El frente visible importa, pero la ventaja real aparece cuando producto, integraciones, despliegue y operaciones dejan de
            vivir como piezas separadas.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {capabilities.map((item) => (
            <article key={item.name} className="rounded-[24px] border border-slate-200 bg-white px-6 py-6 shadow-[0_16px_40px_rgba(15,23,42,0.05)]">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">{item.name}</p>
              <p className="mt-4 text-xl font-semibold text-ink">{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="border-y border-slate-200/80 bg-white/70">
        <div className="mx-auto max-w-7xl px-6 py-20">
          <div className="grid gap-10 lg:grid-cols-[0.9fr,1.1fr]">
            <div className="space-y-4">
              <p className="text-sm font-semibold uppercase tracking-[0.24em] text-accent">How we operate</p>
              <h2 className="text-3xl font-semibold text-ink sm:text-4xl">Minimalismo en la interfaz. Rigor en la operación.</h2>
            </div>
            <div className="grid gap-6">
              {workflow.map((item) => (
                <article key={item.step} className="grid gap-4 border-b border-slate-200 pb-6 last:border-b-0 last:pb-0 md:grid-cols-[84px,1fr]">
                  <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">{item.step}</p>
                  <div>
                    <h3 className="text-2xl font-semibold text-ink">{item.title}</h3>
                    <p className="mt-3 max-w-2xl text-base leading-7 text-slate-600">{item.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-10 lg:grid-cols-[1fr,0.95fr] lg:items-start">
          <div className="space-y-4">
            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-accent">Product line</p>
            <h2 className="text-3xl font-semibold text-ink sm:text-4xl">EasyCount by GetUpSoft</h2>
            <p className="max-w-2xl text-lg leading-8 text-slate-600">
              EasyCount es nuestra línea de producto para operaciones de negocio, control comercial, facturación, trazabilidad y
              trabajo conectado con backoffice. La marca corporativa sigue siendo GetUpSoft; EasyCount es la experiencia de producto.
            </p>
          </div>
          <div className="rounded-[28px] border border-slate-200 bg-white px-6 py-6 shadow-[0_18px_48px_rgba(15,23,42,0.06)]">
            <div className="space-y-4">
              {[
                "Portales por rol: admin, cliente y aliados.",
                "Integración operativa con sistemas externos y middleware.",
                "Flujos repetibles con trazabilidad y control de entorno.",
                "Base técnica preparada para escalar sin rehacer todo el stack.",
              ].map((line) => (
                <div key={line} className="border-b border-slate-100 pb-4 last:border-b-0 last:pb-0">
                  <p className="text-base leading-7 text-slate-700">{line}</p>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link className="rounded-full bg-ink px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800" to="/productos/easycount">
                Ver producto
              </Link>
              <Link
                className="rounded-full border border-slate-300 px-5 py-3 text-sm font-semibold text-slate-800 transition hover:border-accent hover:text-accent"
                to="/contacto"
              >
                Hablar con GetUpSoft
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
