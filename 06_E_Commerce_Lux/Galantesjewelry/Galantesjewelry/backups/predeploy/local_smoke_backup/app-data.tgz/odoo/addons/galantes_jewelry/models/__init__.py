from . import utils
from . import res_partner
from . import product_template
from . import product_gallery
from . import product_extension
from . import appointment
from . import cms_settings
from . import account_move
